package com.vaagdevi.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import kotlin.math.pow
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

 class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        find.setOnClickListener {

            val edt ="Square:"+ed.text.toString().toInt() * ed.text.toString().toInt();
            Toast.makeText(this,edt ,Toast.LENGTH_LONG).show();
        }

        }
    }




