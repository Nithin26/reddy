package com.vaagdevi.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Main2Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
    }
}
2. interface name {





    fun callMe() {

        println("hlo mr ")



    }

}



interface age {

    fun callMe() {

        println("you are 18 year old")

    }

}



class C: name, age {

    override fun callMe() {

        super<name>.callMe()

        super<age>.callMe()

    }

}



fun main(args: Array<String>) {

    val obj = C()





    obj.callMe()

}

3. class Outer {





    class Nested {

        val a = "25"

        fun callMe() = "your value is $a"

    }

}



fun main(args: Array<String>) {



    println(Outer.Nested().a)





    val nested = Outer.Nested()

    println(nested.callMe())

}

4. fun main(args: Array<String>) {

    val base = 1

    val exp = 5

    val result = Math.pow(base.toDouble(), exp.toDouble())



    println("Answer = $result")

}

5. fun main(args: Array<String>) {

    val num = 1091

    println("your number: $num")

    var flag = false

    for (i in 2..num / 2) {



        if (num % i == 0) {

            flag = true

            break

        }

    }



    if (!flag)

        println("$num is a prime number.")

    else

        println("$num is not a prime number.")

}

6. fun main(args: Array<String>) {

    val num = 10



    repeat(num){

        println("HEllo")

    }

    println("hello repeated $num times")

}

7. fun main(args: Array<String>) {

    val line: String

    val subStr: String

    line = readLine().toString()



    subStr = readLine().toString()



    if (line.contains(subStr)) {

        println("String '$line' contains substring '$subStr'")

    } else {

        println("String '$line' doesn't contain substring '$subStr'")

    }

}

8. fun main(args: Array<String>) {



    val num = mutableListOf(1, 2, 3, 4, 5)

    val search = 6

    var found = false



    for (n in num) {

        if (n == search) {

            found = true

            break

        }

    }



    if (found)

        println("$search is available.")

    else



        println("error!! $search not available.")



}